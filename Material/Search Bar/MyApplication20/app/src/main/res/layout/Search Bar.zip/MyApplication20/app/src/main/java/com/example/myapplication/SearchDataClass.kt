package com.example.myapplication

data class SearchDataClass(
    val name: String,
    val surName: String
)
