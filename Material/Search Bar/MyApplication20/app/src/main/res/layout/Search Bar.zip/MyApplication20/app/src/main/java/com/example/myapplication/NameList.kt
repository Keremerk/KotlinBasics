package com.example.myapplication

object NameList {
    val nameList = arrayListOf(
        SearchDataClass("Mini","Mouse"),
        SearchDataClass("Mickey","Mouse"),
        SearchDataClass("Michael","Jordan"),
        SearchDataClass("Robert","Baratheon"),
        SearchDataClass("Tom","Cat"),
        SearchDataClass("Jerry","Mouse"),
        SearchDataClass("John","Dalton"),
        SearchDataClass("Jeff","Bezos"),
        SearchDataClass("Elon","Musk"),
        SearchDataClass("Donald","Trump"),
        SearchDataClass("Sylvester","Cat"),
        SearchDataClass("Tweety","Bird"),
        SearchDataClass("RedKit","Cowboy")
    )
}